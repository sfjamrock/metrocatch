<?php
/**
 * @file
 * Template for "Purchase History" page
 * Varibles:
 *   - $orders: array of order objects
 *   - $purchases: themed order list
 *   - $account: user account object
 */
?>
<div class="metrocatch-uc-purchase-history">
  <?php print $purchases; ?>
</div>

