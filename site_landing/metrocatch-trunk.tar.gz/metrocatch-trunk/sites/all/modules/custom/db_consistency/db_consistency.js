Drupal.behaviors.db_consistency = function (context) {
  $('#edit-check-button', context).toggle(
    function() {
      $('.db-consistency-check-test input').attr('checked', true);
      $(this).val(Drupal.t('Deselect all'));
    },
    function() {
      $('.db-consistency-check-test input').removeAttr('checked');
      $(this).val(Drupal.t('Select all'));
    }
  )
}

/**
 * Behavior for page with test
 */
Drupal.behaviors.db_consistency_groups = function (context) {
  function dbConsistencyApplyFilters(container) {
    // search for active links
    link = container.find('.db-consistency-test-groups a.active');
    // if there are no active link, activate "all" link
    if (link.size() == 0) {
      container.find('.db-consistency-test-groups a[href="#all"]').addClass('active');
      key = 'all';
    }
    else {
      key = link.attr('href').substr(1);
    }
    // construct selector from key and values of chackboxes
    // show all test, if "all" selected
    if (key == 'all') {
      selector = '';
    }
    else {
      selector = '.group-'+ key;
    }
    // hide all record
    container.find('.db-consistency-tests .db-consistency-test-result').hide();
    // show required
    container.find('.db-consistency-tests .db-consistency-test-result' + selector).show();
  }

  // TODO: fetch active tab from settings
  // 1. initially renew filters
  dbConsistencyApplyFilters($('#db-consistency-test-form', context));

  // 2. attach handler on links
  $('.db-consistency-test-groups ul li a', context).click(function(){
    link = $(this);
    // search container
    container = link.parents('form');
    // unactivate last tab
    container.find('.db-consistency-test-groups a.active').removeClass('active');
    // activate current link
    link.addClass('active');
    // apply selected filters
    dbConsistencyApplyFilters(container);
  });
  
  // 2. attach handler on checkboxes 
  $('#db-consistency-test-form .db-consistency-show-checkboxes input', context).click(function(){
    dbConsistencyApplyFilters($(this).parents('form'));
  });
}

