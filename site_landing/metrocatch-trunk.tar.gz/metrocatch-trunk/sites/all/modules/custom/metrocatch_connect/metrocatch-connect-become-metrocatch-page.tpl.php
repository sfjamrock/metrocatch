<?php
/**
 * @file
 * Template of "Become a MetroCatch" page
 * variables:
 *   - $purchase_form - form with CC and billing info
 *   - $select_form - form for selecting select details of the feature
 */
?>
<?php print $purchase_form; ?>
